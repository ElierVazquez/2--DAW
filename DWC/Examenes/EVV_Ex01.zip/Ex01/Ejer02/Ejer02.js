function amarillo() {
    document.getElementById("res").setAttribute("style", "background-color: yellow;");
}

function naranja() {
    document.getElementById("res").setAttribute("style", "background-color: orange;");
}

function rojo() {
    document.getElementById("res").setAttribute("style", "background-color: red;");
}

function verde() {
    document.getElementById("res").setAttribute("style", "background-color: green;");
}

function azul() {
    document.getElementById("res").setAttribute("style", "background-color: blue;");
}